(() => {
  const canvas = document.getElementById("stars");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let w = 0, h = 0, stars = [], frame = 0;
  const mouse = {x:0,y:0};
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    canvas.width = w*dpr; canvas.height = h*dpr;
    canvas.style.width = w+"px"; canvas.style.height = h+"px";
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const count = w < 600 ? 65 : 110;
    stars = Array.from({length:count},()=>({
      x:Math.random()*w-w/2, y:Math.random()*h-h/2,
      z:Math.random()*w+1, bx:Math.random()*w-w/2, by:Math.random()*h-h/2
    }));
  }
  function draw() {
    ctx.fillStyle="#020617"; ctx.fillRect(0,0,w,h);
    for (const s of stars) {
      if (!reducedMotion) s.z -= 1.2;
      if (s.z <= 1) { s.z=w; s.x=s.bx; s.y=s.by; }
      const k=128/s.z;
      const px=(s.x+(mouse.x-w/2)*.00035*s.z)*k+w/2;
      const py=(s.y+(mouse.y-h/2)*.00035*s.z)*k+h/2;
      if(px<0||px>w||py<0||py>h) continue;
      ctx.beginPath(); ctx.arc(px,py,Math.max(.5,(1-s.z/w)*2.4),0,Math.PI*2);
      ctx.fillStyle="rgba(56,189,248,.85)"; ctx.shadowBlur=6; ctx.shadowColor="#38bdf8"; ctx.fill();
    }
    ctx.shadowBlur=0;
    if(!document.hidden && !reducedMotion) frame=requestAnimationFrame(draw);
  }
  window.addEventListener("mousemove",e=>{mouse.x=e.clientX;mouse.y=e.clientY;},{passive:true});
  window.addEventListener("resize",resize);
  document.addEventListener("visibilitychange",()=>{cancelAnimationFrame(frame);if(!document.hidden)draw();});
  resize(); draw();
})();
